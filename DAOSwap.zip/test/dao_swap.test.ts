const {assert} = require('chai');
const {BN, constants, expectEvent, expectRevert, time} = require('@openzeppelin/test-helpers');
const {formatUnits, parseEther} = require("ethers/lib/utils");

const MockERC20 = artifacts.require("./mock/MockERC20.sol");
const DAOFactory = artifacts.require("./DAOFactory.sol");
const DAOPair = artifacts.require("./DAOPair.sol");
const DAORouter = artifacts.require("./DAORouter.sol");
const WBNB = artifacts.require("./WBNB.sol");

contract("Starting test...", ([alice, bob, carol, david, erin, swap2earnRouter]) => {

    describe("Forked passed, so skip test", async () => {

        it("forked passed, so skip test", async function () {
        });

    });
});