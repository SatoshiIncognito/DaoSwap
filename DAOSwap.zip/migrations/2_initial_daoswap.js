const DAOFactory = artifacts.require("DAOFactory");
const DAORouter = artifacts.require("DAORouter");

const feeToSetterAddress = "0xfDFbC7F7a87223E48bDad22B9bacf8d1A01f013f";
const WBNBAddress = "0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd";
const swap2earnRouterAddress = "0x298810E38B4d894D44C33a1340e4255d0C3Cc110";

module.exports = function (deployer, network, accounts) {
    if (network == "test") {
        //use `test` for unitest
        return;
    }

    deployer.then(async () => {
        await deployer.deploy(DAOFactory, feeToSetterAddress);
        await deployer.deploy(DAORouter, DAOFactory.address, WBNBAddress, swap2earnRouterAddress);
    });

};
