const MockERC20 = artifacts.require("mock/MockERC20");
const SwapToEarnUpgradeableProxy = artifacts.require("SwapToEarnUpgradeableProxy");
const SwapToEarn = artifacts.require("SwapToEarn");

const ADDRESS_ZERO = "0x0000000000000000000000000000000000000000";
let daoAddress = "";

module.exports = function (deployer, network, accounts) {
    if (network == "test") {
        //use `test` for unitest
        return;
    }
    deployer.then(async () => {
        if (daoAddress == "") {
            if (network == "bsctestnet") {
                console.log("daoAddress is empty, will deploy mock erc20 token as DAO token on bsctestnet");
                await deployer.deploy(MockERC20, "DAO Token", "DAO", "100000000000000000000000000");
                daoAddress = MockERC20.address;
                // await daoInstance.mintTokens("10000");
                console.log("daoAddress=>", daoAddress);
            } else {
                throw "daoAddress not config!";
            }
        }

        await deployer.deploy(SwapToEarn);
        await deployer.deploy(SwapToEarnUpgradeableProxy, SwapToEarn.address);
        let swap2earn = await SwapToEarn.at(SwapToEarnUpgradeableProxy.address);
        await swap2earn.init(daoAddress, ADDRESS_ZERO);
        console.log("DAO=>", (await swap2earn.DAO()));
        console.log("swapRouter=>", (await swap2earn.swapRouter()));
    });

};
