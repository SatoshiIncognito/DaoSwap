const {assert} = require('chai');
const {BN, constants, expectEvent, expectRevert, time} = require('@openzeppelin/test-helpers');
const {formatUnits, parseEther} = require("ethers/lib/utils");

const MockERC20 = artifacts.require("./mock/MockERC20.sol");
const SwapToEarnUpgradeableProxy = artifacts.require("./SwapToEarnUpgradeableProxy.sol");
const SwapToEarn = artifacts.require("./SwapToEarn.sol");
const ADDRESS_ZERO = "0x0000000000000000000000000000000000000000";

contract("Starting test SwapToEarn ...", ([alice, bob, cat, dog, swapRouter, deployer]) => {
    let tokenDAO;
    let tokenA;
    let tokenB;
    let tokenPair;
    let swap2earnProxy;
    let swap2earnLogic;
    let swap2earn;

    before(async () => {
        tokenA = await MockERC20.new("Token A", "TA", parseEther("10000000"), {from: deployer});
        tokenB = await MockERC20.new("Token B", "TB", parseEther("10000000"), {from: deployer});
        tokenPair = await MockERC20.new("Token Pair", "TPAIR", parseEther("10000000"), {from: deployer});

        tokenDAO = await MockERC20.new("Token DAO", "DAO", parseEther("10000000"), {from: deployer});
        //Deploy logic contract
        swap2earnLogic = await SwapToEarn.new({from: deployer});
        // Deploy proxy contract
        swap2earnProxy = await SwapToEarnUpgradeableProxy.new(swap2earnLogic.address, {from: deployer});
        // use proxy contract address as swap2earn
        swap2earn = await SwapToEarn.at(swap2earnProxy.address);
        //init variables & status
        await swap2earn.init(tokenDAO.address, swapRouter, {from: deployer});
        await swap2earn.setPairHasReward(tokenPair.address, true, {from: deployer});
        assert.equal((await swap2earn.pairHasReward(tokenPair.address)).toString(), (true).toString());


        await tokenA.mintTokens(parseEther("100000"), {from: alice});
        assert.equal((await tokenA.balanceOf(alice)).toString(), parseEther("100000").toString());
        await tokenB.mintTokens(parseEther("100000"), {from: alice});
        assert.equal((await tokenB.balanceOf(alice)).toString(), parseEther("100000").toString());
        await tokenDAO.mintTokens(parseEther("1000000"), {from: alice});
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), parseEther("1000000").toString());

        assert.equal((await tokenDAO.balanceOf(deployer)).toString(), parseEther("10000000").toString());
        await tokenDAO.approve(swap2earn.address, parseEther("10000000"), {from: deployer});
        await swap2earn.addTokenRewards(tokenDAO.address, parseEther("10000000"), {from: deployer});
        assert.equal((await tokenDAO.balanceOf(deployer)).toString(), parseEther("0").toString());
        assert.equal((await tokenDAO.balanceOf(swap2earn.address)).toString(), parseEther("10000000").toString());

    });


    it("1) Check variables", async function () {

        assert.equal((await swap2earn.swapRouter()).toString(), swapRouter.toString());
        assert.equal((await swap2earn.owner()).toString(), deployer.toString());

    });


    it("2) Test wrong caller", async function () {
        await expectRevert(
            swap2earn.setPairHasReward(tokenDAO.address, true, {from: alice}),
            "Ownable: caller is not the owner"
        );

        await expectRevert(
            swap2earn.swapCall({
                user: cat,
                pair: tokenB.address,
                inviter: dog,
                input: tokenA.address,
                output: tokenDAO.address,
                amountIn: 10000,
                amountOut: 2000
            }, {from: alice}),
            "not swap router"
        );
    });


    it("3) Test mock swap", async function () {

        await swap2earn.swapCall({
            user: cat,
            pair: tokenPair.address,
            inviter: dog,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 10000,
            amountOut: 2000
        }, {from: swapRouter});

        //output 2000, 1‰ is 2
        assert.equal((await tokenDAO.balanceOf(cat)).toString(), (2).toString());
        //output 2000, 1‰ is 2
        assert.equal((await tokenDAO.balanceOf(dog)).toString(), (2).toString());

        assert.equal((await swap2earn.swapRewards(cat, tokenDAO.address)).toString(), (2).toString());
        assert.equal((await swap2earn.inviteRewards(dog)).toString(), (2).toString());

        await swap2earn.swapCall({
            user: cat,
            pair: tokenPair.address,
            inviter: dog,
            input: tokenDAO.address,
            output: tokenB.address,
            amountIn: 10000,
            amountOut: 2000
        }, {from: swapRouter});

        //input 10000, 1‰ is 10
        assert.equal((await tokenDAO.balanceOf(cat)).toString(), (2 + 10).toString());
        //input 10000, 1‰ is 10
        assert.equal((await tokenDAO.balanceOf(dog)).toString(), (2 + 10).toString());

        assert.equal((await swap2earn.swapRewards(cat, tokenDAO.address)).toString(), (2 + 10).toString());
        assert.equal((await swap2earn.inviteRewards(dog)).toString(), (2 + 10).toString());

        await swap2earn.swapCall({
            user: cat,
            pair: tokenPair.address,
            inviter: dog,
            input: tokenA.address,
            output: tokenB.address,
            amountIn: 10000,
            amountOut: 2000
        }, {from: swapRouter});

        //no rewards
        assert.equal((await tokenDAO.balanceOf(cat)).toString(), (2 + 10 + 0).toString());
        assert.equal((await tokenDAO.balanceOf(dog)).toString(), (2 + 10 + 0).toString());

        assert.equal((await swap2earn.swapRewards(cat, tokenDAO.address)).toString(), (2 + 10 + 0).toString());
        assert.equal((await swap2earn.inviteRewards(dog)).toString(), (2 + 10 + 0).toString());

        await swap2earn.swapCall({
            user: cat,
            pair: tokenA.address,
            inviter: dog,
            input: tokenDAO.address,
            output: tokenB.address,
            amountIn: 10000,
            amountOut: 2000
        }, {from: swapRouter});

        //no rewards too
        assert.equal((await tokenDAO.balanceOf(cat)).toString(), (2 + 10 + 0 + 0).toString());
        assert.equal((await tokenDAO.balanceOf(dog)).toString(), (2 + 10 + 0 + 0).toString());


        await swap2earn.swapCall({
            user: cat,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 10000,
            amountOut: 20000
        }, {from: swapRouter});

        //output 20000, 1‰ is 20
        assert.equal((await tokenDAO.balanceOf(cat)).toString(), (2 + 10 + 0 + 0 + 20).toString());
        //no inviter rewards
        assert.equal((await tokenDAO.balanceOf(dog)).toString(), (2 + 10 + 0 + 0).toString());
    });


    it("4) Test stake DAO ", async function () {

        await tokenDAO.approve(swap2earn.address, parseEther("1000000000"), {from: alice});

        await swap2earn.stakeDAO(parseEther("199.9999"), {from: alice});
        assert.equal((await swap2earn.daoStakedInfo(alice))[0].toString(), (parseEther("199.9999")).toString());

        let aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());

        // console.log("alice DAO balance:", aliceDAO.toString());

        await swap2earn.swapCall({
            user: alice,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 123456,
            amountOut: 10000
        }, {from: swapRouter});

        //output 10000, 1‰ is 10
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN("10"))).toString());

        await swap2earn.stakeDAO(parseEther("0.0001"), {from: alice});
        assert.equal((await swap2earn.daoStakedInfo(alice))[0].toString(), (parseEther("200")).toString());
        aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());

        await swap2earn.swapCall({
            user: alice,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 123456,
            amountOut: 10000
        }, {from: swapRouter});

        //output 10000, 2‰ is 20
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN("20"))).toString());

        await swap2earn.stakeDAO(parseEther("299.9"), {from: alice});
        assert.equal((await swap2earn.daoStakedInfo(alice))[0].toString(), (parseEther("499.9")).toString());
        aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());

        await swap2earn.swapCall({
            user: alice,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 123456,
            amountOut: 10000
        }, {from: swapRouter});

        //output 10000, 2‰ is 20
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN("20"))).toString());


        await swap2earn.stakeDAO(parseEther("0.1"), {from: alice});
        assert.equal((await swap2earn.daoStakedInfo(alice))[0].toString(), (parseEther("500")).toString());
        aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());

        await swap2earn.swapCall({
            user: alice,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 123456,
            amountOut: 10000
        }, {from: swapRouter});

        //output 10000, 3‰ is 30
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN("30"))).toString());

        await swap2earn.stakeDAO(parseEther("499"), {from: alice});
        assert.equal((await swap2earn.daoStakedInfo(alice))[0].toString(), (parseEther("999")).toString());
        aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());

        await swap2earn.swapCall({
            user: alice,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 123456,
            amountOut: 10000
        }, {from: swapRouter});

        //output 10000, 3‰ is 30
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN("30"))).toString());

        await swap2earn.stakeDAO(parseEther("1"), {from: alice});
        assert.equal((await swap2earn.daoStakedInfo(alice))[0].toString(), (parseEther("1000")).toString());
        aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());

        await swap2earn.swapCall({
            user: alice,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 123456,
            amountOut: 10000
        }, {from: swapRouter});

        //output 10000, 4‰ is 40
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN("40"))).toString());

        await swap2earn.stakeDAO(parseEther("3999"), {from: alice});
        assert.equal((await swap2earn.daoStakedInfo(alice))[0].toString(), (parseEther("4999")).toString());
        aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());

        await swap2earn.swapCall({
            user: alice,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 123456,
            amountOut: 10000
        }, {from: swapRouter});

        //output 10000, 4‰ is 40
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN("40"))).toString());

        await swap2earn.stakeDAO(parseEther("1"), {from: alice});
        assert.equal((await swap2earn.daoStakedInfo(alice))[0].toString(), (parseEther("5000")).toString());
        aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());

        await swap2earn.swapCall({
            user: alice,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 123456,
            amountOut: 10000
        }, {from: swapRouter});

        //output 10000, 6‰ is 60
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN("60"))).toString());

    });


    it("5) Test unstake DAO ", async function () {
        await expectRevert(
            swap2earn.unstakeDAO(parseEther("4501"), {from: alice}),
            "unstake DAO: not time yet"
        );

        await time.increase(20);
        // change to 20 seconds
        await swap2earn.setUnstakeWithdrawSeconds(20, {from: deployer});
        await time.advanceBlock();

        let aliceTotalStaked = (await swap2earn.daoStakedInfo(alice))[0];
        let aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());

        // console.log((await swap2earn.daoStakedInfo(alice))[0].toString());//5000

        await swap2earn.unstakeDAO(parseEther("4501"), {from: alice});
        assert.equal((await swap2earn.daoStakedInfo(alice))[0].toString(), (parseEther("499")).toString());
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN(parseEther("4501").toString()))).toString());

        aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());


        // console.log("alice DAO balance:", aliceDAO.toString());

        await swap2earn.swapCall({
            user: alice,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 123456,
            amountOut: 10000
        }, {from: swapRouter});

        //output 10000, 2‰ is 20
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN("20"))).toString());

        await swap2earn.unstakeDAO(parseEther("499"), {from: alice});
        assert.equal((await swap2earn.daoStakedInfo(alice))[0].toString(), (parseEther("0")).toString());

        aliceDAO = new BN((await tokenDAO.balanceOf(alice)).toString());

        await swap2earn.swapCall({
            user: alice,
            pair: tokenPair.address,
            inviter: ADDRESS_ZERO,
            input: tokenA.address,
            output: tokenDAO.address,
            amountIn: 123456,
            amountOut: 10000
        }, {from: swapRouter});

        //output 10000, 1‰ is 10
        assert.equal((await tokenDAO.balanceOf(alice)).toString(), (aliceDAO.add(new BN("10"))).toString());

        await expectRevert(
            swap2earn.unstakeDAO(parseEther("0"), {from: alice}),
            "amount: 0"
        );

        await expectRevert(
            swap2earn.unstakeDAO(1, {from: alice}),
            "unstake DAO: not good"
        );
    });
});